let btn=document.querySelector('#new-quote');
let quote =document.querySelector('.quote');
let per =document.querySelector('.person');

const quotes = [
    {
      quote: `"The best way to find yourself is to lose yourself in the service of others."`,
      person: `Mahatma Gandhi`
    },
    {
      quote: `"Imagination is more important than knowledge. For knowledge is limited, whereas imagination embraces the entire world."`,
      person: `Albert Einstein`
    },
    {
      quote: `"If I have seen further it is by standing on the shoulders of Giants."`,
      person: `Isaac Newton`
    },
    {
      quote: `"Nothing in life is to be feared, it is only to be understood. Now is the time to understand more, so that we may fear less."`,
      person: `Marie Curie`
    },
    {
      quote: `"Learning never exhausts the mind."`,
      person: `Leonardo da Vinci`
    },
    {
      quote: `"It always seems impossible until it's done."`,
      person: `Nelson Mandela`
    },
    {
      quote: `"Intelligence is the ability to adapt to change."`,
      person: `Stephen Hawking`
    },
    {
      quote: `"Be the change that you wish to see in the world."`,
      person: `Mahatma Gandhi`
    },
    {
      quote: `"The time is always right to do what is right."`,
      person: `Martin Luther King Jr.`
    },
    {
      quote: `"Genius is one percent inspiration and ninety-nine percent perspiration."`,
      person: `Thomas Edison`
    },
    {
      quote: `"It does not matter how slowly you go as long as you do not stop."`,
      person: `Confucius`
    }
  ];
  
  btn.addEventListener('click',()=>{
    const random=Math.floor(Math.random() *quotes.length);
    quote.innerText=quotes[random].quote;
    per.innerText=quotes[random].person;

  })